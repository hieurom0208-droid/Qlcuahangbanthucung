document.querySelector(".search-btn").addEventListener("click", () => {
    let key = document.getElementById("searchInput").value;
    alert("Bạn vừa tìm: " + key);
});
